﻿namespace MergeSort
{
    internal static class MergeHelpers
    {
        public static void Main(int[] args)
        {
            MergeSort.Merge.Main();
        }
    }
}